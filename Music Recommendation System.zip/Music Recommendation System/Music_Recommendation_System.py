"""
================================================
  MUSIC RECOMMENDATION SYSTEM
  Rhombix Technologies - ML Internship Task 1
  Run on: VS Code / Any Python Environment
================================================
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_auc_score
)
from sklearn.preprocessing import LabelEncoder
import warnings

warnings.filterwarnings("ignore")

print("=" * 55)
print("   MUSIC RECOMMENDATION SYSTEM")
print("   Rhombix Technologies - ML Internship Task 1")
print("=" * 55)
print("\n✅ All libraries imported successfully!")

# ─────────────────────────────────────────────
# STEP 1: CREATE DATASET
# ─────────────────────────────────────────────
print("\n📦 Creating dataset...")

np.random.seed(42)
N = 5000

genres  = ['Pop', 'Rock', 'Hip-Hop', 'Jazz', 'Classical', 'EDM', 'R&B', 'Country']
sources = ['search', 'playlist', 'radio', 'artist_page', 'album']

data = {
    'user_id':             [f"U{np.random.randint(1, 501):04d}" for _ in range(N)],
    'song_id':             [f"S{np.random.randint(1, 1001):05d}" for _ in range(N)],
    'genre':               np.random.choice(genres, N),
    'play_count':          np.random.randint(1, 30, N),
    'listen_duration_sec': np.random.randint(30, 300, N),
    'song_duration_sec':   np.random.randint(150, 360, N),
    'hour_of_day':         np.random.randint(0, 24, N),
    'day_of_week':         np.random.randint(0, 7, N),
    'source_type':         np.random.choice(sources, N),
    'num_songs_played':    np.random.randint(5, 200, N),
    'user_age_days':       np.random.randint(30, 1500, N),
}

df = pd.DataFrame(data)
df['listen_pct'] = (df['listen_duration_sec'] / df['song_duration_sec']).clip(0, 1)

prob = (
    0.3 * (df['play_count'] / 30) +
    0.4 * df['listen_pct'] +
    0.2 * (df['num_songs_played'] / 200) +
    0.1 * np.random.rand(N)
)
df['target'] = (prob > 0.5).astype(int)

print(f"   Shape       : {df.shape}")
print(f"   Repeat Rate : {df['target'].mean()*100:.1f}%")
print(f"\n   Sample Data:")
print(df[['user_id','song_id','genre','play_count','listen_pct','target']].head(5).to_string())

# ─────────────────────────────────────────────
# STEP 2: FEATURE ENGINEERING
# ─────────────────────────────────────────────
print("\n🔧 Engineering features...")

le_genre  = LabelEncoder()
le_source = LabelEncoder()
df['genre_enc']    = le_genre.fit_transform(df['genre'])
df['source_enc']   = le_source.fit_transform(df['source_type'])
df['is_weekend']   = df['day_of_week'].isin([5, 6]).astype(int)
df['is_peak_hour'] = df['hour_of_day'].apply(
    lambda h: 1 if (7 <= h <= 9 or 17 <= h <= 21) else 0
)

FEATURES = [
    'play_count', 'listen_duration_sec', 'song_duration_sec',
    'listen_pct', 'hour_of_day', 'day_of_week', 'num_songs_played',
    'user_age_days', 'genre_enc', 'source_enc',
    'is_weekend', 'is_peak_hour'
]

X = df[FEATURES]
y = df['target']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"   Train size: {len(X_train)} | Test size: {len(X_test)}")

# ─────────────────────────────────────────────
# STEP 3: TRAIN MODEL
# ─────────────────────────────────────────────
print("\n🤖 Training Random Forest model...")

model = RandomForestClassifier(
    n_estimators=150,
    max_depth=10,
    min_samples_split=5,
    random_state=42,
    n_jobs=-1
)
model.fit(X_train, y_train)
print("   Model trained successfully!")

# ─────────────────────────────────────────────
# STEP 4: EVALUATE
# ─────────────────────────────────────────────
y_pred  = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]
acc     = accuracy_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_proba)

print("\n" + "=" * 55)
print("📈 MODEL EVALUATION")
print("=" * 55)
print(f"   Accuracy  : {acc*100:.2f}%")
print(f"   ROC-AUC   : {roc_auc:.4f}")
print(f"\n   Classification Report:\n")
print(classification_report(y_test, y_pred,
      target_names=["Not Repeated", "Repeated"]))

# ─────────────────────────────────────────────
# STEP 5: RECOMMENDATION FUNCTION
# ─────────────────────────────────────────────
def recommend_songs(user_id, top_n=5):
    """
    Recommends top N songs for a given user.
    Songs with highest repeat probability are recommended.
    """
    user_rows  = df[df['user_id'] == user_id].copy()
    if user_rows.empty:
        print(f"   User {user_id} not found.")
        return pd.DataFrame()

    candidates = user_rows[user_rows['target'] == 0].copy()
    if candidates.empty:
        print(f"   No new songs to recommend for {user_id}.")
        return pd.DataFrame()

    candidates['repeat_probability'] = model.predict_proba(
        candidates[FEATURES])[:, 1]

    top = (candidates
           .sort_values('repeat_probability', ascending=False)
           .drop_duplicates('song_id')
           .head(top_n)[['song_id', 'genre', 'source_type', 'repeat_probability']]
           .reset_index(drop=True))
    top.index += 1
    return top

print("=" * 55)
print("🎵 SONG RECOMMENDATIONS")
print("=" * 55)
for uid in df['user_id'].unique()[:3]:
    print(f"\n   Top 5 for User: {uid}")
    print("   " + "-" * 45)
    recs = recommend_songs(uid)
    if not recs.empty:
        print(recs.to_string())

# ─────────────────────────────────────────────
# STEP 6: VISUALIZATIONS
# ─────────────────────────────────────────────
print("\n📊 Generating charts...")

fig, axes = plt.subplots(2, 3, figsize=(18, 11))
fig.suptitle(
    "Music Recommendation System — Rhombix Technologies ML Internship | Task 1",
    fontsize=14, fontweight='bold'
)

# 1. Target Distribution
ax = axes[0, 0]
counts = df['target'].value_counts()
bars = ax.bar(['Not Repeated (0)', 'Repeated (1)'],
              counts.values, color=['#4C72B0', '#DD8452'],
              edgecolor='white', width=0.5)
ax.set_title('Target Distribution', fontweight='bold')
ax.set_ylabel('Count')
for bar, val in zip(bars, counts.values):
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + 40, str(val), ha='center', fontweight='bold')

# 2. Genre vs Repeat Rate
ax = axes[0, 1]
genre_rate = df.groupby('genre')['target'].mean().sort_values(ascending=False)
sns.barplot(x=genre_rate.values, y=genre_rate.index, ax=ax, palette='viridis')
ax.set_title('Repeat Listen Rate by Genre', fontweight='bold')
ax.set_xlabel('Repeat Rate')
ax.set_xlim(0, 1)

# 3. Feature Importances
ax = axes[0, 2]
importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
importances.plot(kind='barh', ax=ax, color='steelblue')
ax.set_title('Feature Importances', fontweight='bold')
ax.set_xlabel('Importance Score')

# 4. Confusion Matrix
ax = axes[1, 0]
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
            xticklabels=['Not Repeated', 'Repeated'],
            yticklabels=['Not Repeated', 'Repeated'])
ax.set_title('Confusion Matrix', fontweight='bold')
ax.set_ylabel('Actual')
ax.set_xlabel('Predicted')

# 5. Listen % by Target
ax = axes[1, 1]
df[df['target'] == 0]['listen_pct'].hist(ax=ax, alpha=0.6, bins=30,
                                          color='#4C72B0', label='Not Repeated')
df[df['target'] == 1]['listen_pct'].hist(ax=ax, alpha=0.6, bins=30,
                                          color='#DD8452', label='Repeated')
ax.set_title('Listen % Distribution by Target', fontweight='bold')
ax.set_xlabel('Proportion of Song Listened')
ax.set_ylabel('Count')
ax.legend()

# 6. Play Count vs Repeat Rate
ax = axes[1, 2]
df['play_count_bin'] = pd.cut(df['play_count'], bins=[1, 5, 10, 15, 20, 30])
repeat_by_plays = df.groupby('play_count_bin', observed=True)['target'].mean()
repeat_by_plays.plot(kind='bar', ax=ax, color='mediumseagreen', edgecolor='white')
ax.set_title('Repeat Rate by Play Count Range', fontweight='bold')
ax.set_xlabel('Play Count Range')
ax.set_ylabel('Repeat Listen Rate')
ax.tick_params(axis='x', rotation=30)

plt.tight_layout()
plt.savefig('music_recommendation_results.png', dpi=150, bbox_inches='tight')
print("   Chart saved as 'music_recommendation_results.png'")
plt.show()

print("\n" + "=" * 55)
print("✅ TASK 1 COMPLETE!")
print(f"   Accuracy : {acc*100:.2f}%  |  ROC-AUC : {roc_auc:.4f}")
print("=" * 55)
